#!/bin/bash
# Launch a Jupyter Server to serve the QLM Documentation & Notebooks
# Atos R&D QLM CI Team

# Ascii Coloring
export N_='\033[0m'         # Reset
export R_='\033[0;31m'      # Red
export BG_='\033[1;32m'     # Bold Green

error=0

QLM_VERSION=


#
# usage
#
usage()
{
echo "
usage: launch_qlm_notebooks.sh

This script does not take any paramaters.

Configuration parameters will be read read from
(the file will be auto configured at first launch):
    ${JUPYTER_CONFIG_DIR:-\$JUPYTER_CONFIG_DIR}/jupyter_notebook_config.py

Before to invoke this script, you can:

    export JUPYTER_PORT=<listen_port>  to set the Jupyter server listen port (def=8888)
    export JUPYTER_OPTS=<param>        to expose/alter other parameters

NOTE:
    get_qlm_version returns the QLM version
"
exit 1
}


#
# setup_config
#
setup_config()
{
echo "Setting up base Jupyter configuration"
sed -i -e "s/^#c.NotebookApp.allow_origin = ''/c.NotebookApp.allow_origin = '*'/" \
       -e "s:^#c.NotebookApp.default_url = '/tree':c.NotebookApp.default_url = '/files/index.html':" \
       -e "s/^#c.NotebookApp.disable_check_xsrf = False/c.NotebookApp.disable_check_xsrf = True/" \
       -e "s/^#c.NotebookApp.ip = 'localhost'/c.NotebookApp.ip = '0.0.0.0'/" \
       -e "s/^#c.NotebookApp.max_body_size = 536870912/c.NotebookApp.max_body_size = 1073741824/" \
       -e "s/^#c.NotebookApp.max_buffer_size = 536870912/c.NotebookApp.max_buffer_size = 1073741824/" \
       -e "s/^#c.NotebookApp.open_browser = True/c.NotebookApp.open_browser = False/" \
       -e "s/^#c.NotebookApp.webbrowser_open_new = 2/c.NotebookApp.webbrowser_open_new = 0/" \
    $JUPYTER_CONFIG_DIR/jupyter_notebook_config.py
}

#
# Main
#
if [[ -n $1 ]]; then
    if [[ $1 =~ ^-(h|\?|-help)$ ]]; then
        usage
    else
        echo -e "\n**** Input error"
        usage
    fi
fi

QLM_VERSION="$(/usr/local/bin/get_qlm_version -nc -v 2>/dev/null)"
if [[ -z $QLM_VERSION ]]; then
    if rpm -q qat-tutorial &>/dev/null; then
        echo -e "${R_}The QLM version cannot be determined [get_qlm_version failed]${N_}"
    else
        echo -e "${R_}The QLM version cannot be determined [qat-tutorial is not installed]${N_}"
    fi
    exit 1
fi 

NOTEBOOKDIR="$(/usr/local/bin/get_qlm_version -nc -d 2>/dev/null)"
if [[ ! -d $NOTEBOOKDIR ]]; then
    echo -e "${R_}No notebooks found for QLM version ${QLM_VERSION-?}${N_}"
    exit 1
fi
cd $NOTEBOOKDIR || exit 2

# If you want to run ipython/jupyter yourself from the cmdline, copy/paste the
# next 3 lines so you will use the same env that this script is using
export IPYTHONDIR=$HOME/qlm_notebooks/notebooks_$QLM_VERSION/.ipython
export JUPYTER_CONFIG_DIR=$HOME/qlm_notebooks/notebooks_$QLM_VERSION/.jupyter
export JUPYTER_DATA_DIR=$HOME/qlm_notebooks/notebooks_$QLM_VERSION/.local/share/jupyter

echo "
QLM JUPYTER NOTEBOOKS SERVER

IPYTHONDIR=$IPYTHONDIR
JUPYTER_CONFIG_DIR=$JUPYTER_CONFIG_DIR
JUPYTER_DATA_DIR=$JUPYTER_DATA_DIR

JUPYTER_PORT=${JUPYTER_PORT-8888}
JUPYTER_OPTS=$JUPYTER_OPTS
"

jupyter --paths

# Trust the QLM notebooks
if [[ ! -f $HOME/qlm_notebooks/notebooks_$QLM_VERSION/.qlm/qlm_notebooks_signed ]]; then
    echo; echo "QLM notebooks first time setup, please wait..."
    echo; jupyter notebook --generate-config
    setup_config

    echo; jupyter nbextension enable --py widgetsnbextension
    echo; jupyter nbextension enable jupyter_nbextensions_configurator --py
    echo; jupyter nbextension list

    echo; while read -r notebook; do
        if ! jupyter trust "$notebook" >/dev/null; then
            error=1; break
        fi
    done <<< "$(find $HOME/qlm_notebooks/notebooks_$QLM_VERSION -name "*.ipynb")"
    if ! ((error)); then
        touch $HOME/qlm_notebooks/notebooks_$QLM_VERSION/.qlm/qlm_notebooks_signed
    fi
    echo
fi

# If JUPYTER_PORT is set, use it
JUPYTER_LISTEN_PORT=; [[ -n $JUPYTER_PORT ]] && JUPYTER_LISTEN_PORT="--port $JUPYTER_PORT"

# Start Jupyter
# use numactl --physcpubind=0-<n> jupyter notebook if you want the Jupyter server to use more than 1 CPU (n CPU)
cmd="jupyter notebook $JUPYTER_LISTEN_PORT $JUPYTER_OPTS"
echo -e "\n> $cmd\n"
$cmd

